package pe.edu.upeu.segundaunidadfx;

public class JavaFxApplication {

    public static void main(String[] args) {

        SegundaUnidadFxApplication.main(args);
    }
}

