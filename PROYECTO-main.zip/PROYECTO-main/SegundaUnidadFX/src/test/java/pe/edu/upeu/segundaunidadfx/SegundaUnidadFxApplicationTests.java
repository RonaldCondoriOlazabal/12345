package pe.edu.upeu.segundaunidadfx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SegundaUnidadFxApplicationTests {

	@Test
	void contextLoads() {
	}

}
